#!/usr/bin/env bash
# Provision Kali (NetHunter chroot/proot) for Allmite Ai servers.
# Kali rolling already ships fresh tooling; we only pin Node 22 and add
# the three servers. Run INSIDE the Kali environment as root.
set -euo pipefail

ADDON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Self-update: same contract as the Ubuntu variant (never fatal offline).
if [ -d "$ADDON_DIR/.git" ] && command -v git >/dev/null 2>&1; then
  git -C "$ADDON_DIR" pull --ff-only >/dev/null 2>&1 || true
fi

export DEBIAN_FRONTEND=noninteractive
apt update && apt install -y curl git ca-certificates gnupg cron sqlite3 python3

curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt install -y nodejs
node --version

curl -fsSL https://opencode.ai/install | bash
npm install -g @musistudio/claude-code-router
curl -fsSL https://ollama.com/install.sh | sh || echo "Ollama skipped (disk/RAM?)"

service cron start 2>/dev/null || cron 2>/dev/null || true
echo "[allmite-proot:kali] done. Same servers/ports as Ubuntu variant."
