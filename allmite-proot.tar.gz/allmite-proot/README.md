# allmite-proot — Allmite Ai companion inside proot Ubuntu/Kali on Termux

This is where the servers actually run on a phone-only setup: real glibc
userland, Node 22, opencode, CCR, Ollama (ARM64), plus the full
models-sync collector (opencode + CCR + Ollama inventories).

## Provision (inside `proot-distro login ubuntu`, or your Kali env)

One line fetches the addon itself first (replace USER with the real
GitHub org/user once the repos exist):

```bash
git clone https://github.com/cam724728-maker/allmite-addons ~/allmite-addons
cd ~/allmite-addons/allmite-proot
./provision-ubuntu.sh     # Ubuntu: base + Node 22 + opencode + CCR + ollama + cron
# ./provision-kali.sh     # Kali variant (thinner: uses Kali repos + nodesource)
```

Then start servers as usual (`opencode serve --port 4096`, `ccr start`,
`ollama serve`) — proot shares the phone network, so the app on
`127.0.0.1` sees everything.

## Layout

- `provision-ubuntu.sh` / `provision-kali.sh` — one-shot provisioners.
- `bin/models-sync.sh` — full collector + `--update` (pull missing +
  refresh wanted `WANT_OLLAMA_MODELS`) + `--ensure` (pull-if-missing +
  report missing tools, never silent apt).
- `bin/feed-server.py` — same protocol as Termux variant on
  **127.0.0.1:8098** (different port so both feeds coexist).
- `jobs/setup-cron.sh` — real cron inside proot (`apt install cron`),
  every 6h + log rotation note.

## Notes

- No systemd inside proot (no PID 1): cron daemon started manually and
  re-armed from Termux boot (`allmite-termux` boot hook can
  `proot-distro login ubuntu -- /root/allmite-proot/jobs/keepalive.sh` —
  keepalive pattern documented in README of that repo after first test).
- Ollama ARM64 needs ~2GB download + RAM: prefer small models
  (`qwen2.5-coder:1.5b`) on phones.
