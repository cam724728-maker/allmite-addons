#!/usr/bin/env bash
# Provision proot Ubuntu for Allmite Ai servers (run INSIDE proot-distro ubuntu).
set -euo pipefail

ADDON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Self-update: this addon is a runtime requirement, so a cloned copy
# refreshes itself first (never fails provisioning if offline).
if [ -d "$ADDON_DIR/.git" ] && command -v git >/dev/null 2>&1; then
  git -C "$ADDON_DIR" pull --ff-only >/dev/null 2>&1 || true
fi

export DEBIAN_FRONTEND=noninteractive
apt update && apt install -y curl git ca-certificates gnupg cron sqlite3 python3

# Node.js 22 LTS (servers need 18-24; distro default may be older/newer)
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt install -y nodejs
node --version

# opencode (official Linux ARM64 build runs under proot glibc)
curl -fsSL https://opencode.ai/install | bash
export PATH="$HOME/.opencode/bin:$PATH"
opencode --version || true

# CCR gateway
npm install -g @musistudio/claude-code-router
ccr --version || true

# Ollama (linux-arm64 works under proot; needs disk + RAM — small models!)
curl -fsSL https://ollama.com/install.sh | sh || echo "Ollama install failed (check disk/RAM) — continuing without it"

# cron for the collector (no systemd under proot)
service cron start 2>/dev/null || cron 2>/dev/null || true

echo "[allmite-proot] done. Next: opencode serve --port 4096 | ccr start | ollama serve"
echo "Then wire ~/allmite-proot/bin/models-sync.sh + jobs/setup-cron.sh"
