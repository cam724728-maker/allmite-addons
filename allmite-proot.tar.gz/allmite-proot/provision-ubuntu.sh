#!/usr/bin/env bash
# Provision proot Ubuntu for Allmite Ai servers (run INSIDE proot-distro ubuntu).
set -euo pipefail

ADDON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Self-update: this addon is a runtime requirement, so a cloned copy
# refreshes itself first (never fails provisioning if offline).
if [ -d "$ADDON_DIR/.git" ] && command -v git >/dev/null 2>&1; then
  git -C "$ADDON_DIR" pull --ff-only >/dev/null 2>&1 || true
fi

export DEBIAN_FRONTEND=noninteractive

# All runtime requirements through one checker: present tools are skipped,
# missing ones downloaded (see bin/ensure-packages.sh for the contract).
"$(dirname "${BASH_SOURCE[0]}")/bin/ensure-packages.sh" || {
  echo "[allmite-proot] ensure-packages reported gaps — continuing anyway"
}

# cron for the collector (no systemd under proot)
service cron start 2>/dev/null || cron 2>/dev/null || true
"$ADDON_DIR/jobs/setup-cron.sh" || true

# companion feed on :8098 (the app's alternate URL) — idempotent start
TOKEN_FILE="$HOME/.allmite-token"
if [ ! -f "$TOKEN_FILE" ]; then
  openssl rand -hex 24 2>/dev/null > "$TOKEN_FILE" || \
    head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n' > "$TOKEN_FILE"
  chmod 600 "$TOKEN_FILE"
  echo "[allmite-proot] NEW pairing token created."
fi
FEED_URL="http://127.0.0.1:8098/models.json?token=$(cat "$TOKEN_FILE")"
if curl -fsS --max-time 3 "$FEED_URL" >/dev/null 2>&1; then
  echo "[allmite-proot] feed already answering on :8098."
else
  nohup python3 "$ADDON_DIR/bin/feed-server.py" >/dev/null 2>&1 &
  sleep 2
fi
"$ADDON_DIR/bin/models-sync.sh" now || true

echo
echo "================ ALLMITE AI — CONNECTION SUMMARY ==============="
echo "opencode:  opencode serve --port 4096   (password via OPENCODE_SERVER_PASSWORD)"
echo "CCR:       ccr start   (gateway :3456)"
echo "Ollama:    ollama serve && ollama pull qwen2.5-coder:7b-instruct"
if curl -fsS --max-time 5 "$FEED_URL" >/dev/null 2>&1; then
  echo "Feed:      OK  http://127.0.0.1:8098/models.json?token=YOUR_TOKEN"
else
  echo "Feed:      NOT answering — start it:"
  echo "           nohup python3 $ADDON_DIR/bin/feed-server.py >/dev/null 2>&1 &"
fi
echo "Token:     (paste ONCE in Allmite Ai -> Models sync)"
cat "$TOKEN_FILE"
echo
echo "Status:    http://127.0.0.1:8098/status?token=YOUR_TOKEN"
echo "================================================================"
