#!/usr/bin/env bash
# Cron wiring inside proot Ubuntu/Kali (real cron exists here, unlike
# stock Termux). Run once after provisioning.
set -euo pipefail

ADDON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

service cron start 2>/dev/null || cron 2>/dev/null || true
( crontab -l 2>/dev/null | grep -v "allmite-proot.*models-sync" ; \
  echo "17 */6 * * * $ADDON_DIR/bin/models-sync.sh >>$HOME/.allmite-feed/cron.log 2>&1" \
) | crontab -
echo "[cron] registered every 6h. Manual: $ADDON_DIR/bin/models-sync.sh now"
echo "Note: proot has no systemd — re-run this file if the proot session restarts."
