<#
.SYNOPSIS
  Allmite models-sync companion for native Windows: inventory (and optional
  update) of opencode / CCR / Ollama models into the v1 feed envelope.
.DESCRIPTION
  Modes (default = inventory only, safe to schedule):
    Sync-AllmiteModels.ps1               inventory → feed JSON
    Sync-AllmiteModels.ps1 -Ensure      + pull missing WANT models, report tools
    Sync-AllmiteModels.ps1 -Update      + re-pull wanted models (refresh)
  Feed: %USERPROFILE%\.allmite-feed\models.json (same envelope v1 as the
  Termux/proot/Linux companions). CCR gateway key via $env:CCR_API_KEY.
#>
[CmdletBinding()]
param([switch]$Update, [switch]$Ensure)

$ErrorActionPreference = 'Continue'
$FeedDir = Join-Path $HOME '.allmite-feed'
$FeedFile = Join-Path $FeedDir 'models.json'
$Wanted = @('qwen2.5-coder:7b-instruct')  # edit: models this box must keep
$CcrBase = if ($env:CCR_BASE) { $env:CCR_BASE } else { 'http://127.0.0.1:3456' }
New-Item -ItemType Directory -Force -Path $FeedDir | Out-Null

function Get-OpencodeModels {
  $out = @()
  if (-not (Get-Command opencode -ErrorAction SilentlyContinue)) { return $out }
  foreach ($line in (opencode models 2>$null)) {
    $t = $line.Trim()
    if ($t -match '^[a-z0-9_-]+/') { $out += $t }
  }
  return $out
}

function Get-CcrModels {
  $headers = @{}
  if ($env:CCR_API_KEY) { $headers['Authorization'] = "Bearer $($env:CCR_API_KEY)" }
  try {
    $r = Invoke-RestMethod -Uri "$CcrBase/v1/models" -Headers $headers -TimeoutSec 20
    $list = @()
    foreach ($m in ($r.data ?? $r.models ?? @())) {
      $id = $m.id ?? $m.name
      if ($id) { $list += $id }
    }
    return $list
  } catch { return @() }
}

function Get-OllamaModels {
  if (-not (Get-Command ollama -ErrorAction SilentlyContinue)) { return @() }
  $lines = ollama list 2>$null | Select-Object -Skip 1
  $out = @()
  foreach ($ln in $lines) { $n = ($ln -split '\s+')[0]; if ($n) { $out += $n } }
  return $out
}

function Get-Versions {
  $v = @{}
  try {
    $n = npm ls -g @musistudio/claude-code-router --depth=0 2>$null | Select-String -Pattern '(\d+\.\d+\.\d+)' | Select-Object -First 1
    if ($n) { $v['ccr'] = $n.Matches[0].Value }
  } catch {}
  try {
    $o = (opencode --version 2>$null) | Select-String -Pattern '(\d+\.\d+\.\d+)' | Select-Object -First 1
    if ($o) { $v['opencode'] = $o.Matches[0].Value }
  } catch {}
  return $v
}

$doc = [ordered]@{
  v = 1
  updatedAt = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
  sources = [ordered]@{
    opencode = [ordered]@{ models = @(Get-OpencodeModels); origin = 'cli' }
    ccr = [ordered]@{ models = @(Get-CcrModels); origin = 'gateway' }
    ollama = [ordered]@{ models = @(Get-OllamaModels); origin = 'cli' }
    versions = Get-Versions
  }
}
$doc | ConvertTo-Json -Depth 5 | Out-File -Encoding utf8 $FeedFile
Copy-Item $FeedFile (Join-Path $FeedDir '.last-state.json') -Force
Write-Host "[models-sync] feed refreshed: $FeedFile"

if ($Update -or $Ensure) {
  if (-not (Get-Command ollama -ErrorAction SilentlyContinue)) {
    Write-Host '[models-sync] missing tool: ollama (run Setup-AllmiteServer.ps1)'
  } else {
    $have = @(Get-OllamaModels)
    foreach ($m in $Wanted) {
      if ($have -contains $m) {
        if ($Update) { ollama pull $m }
      } else {
        Write-Host "[models-sync] pulling missing model: $m"
        ollama pull $m
      }
    }
  }
  foreach ($t in @('opencode', 'ccr', 'node', 'npm')) {
    if (-not (Get-Command $t -ErrorAction SilentlyContinue)) {
      Write-Host "[models-sync] missing tool: $t"
    }
  }
  if ($Update -or $Ensure) {
    # Re-run inventory so the feed reflects what was just pulled.
    & $PSCommandPath
  }
}
