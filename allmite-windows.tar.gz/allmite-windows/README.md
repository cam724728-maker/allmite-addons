# allmite-windows — Allmite Ai server setup for a Windows PC controlled by phone

Turns a Windows machine into the app's backend: Node LTS, opencode, CCR,
Ollama, firewall rules, OpenSSH server (for Termux SSH tunnels), and a
health check. Run in **PowerShell as Administrator**.

## Install

One line fetches the addon itself first (replace USER with the real
GitHub org/user once the repos exist). In PowerShell **as Administrator**:

```powershell
git clone https://github.com/USER/allmite-windows C:\allmite-windows
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
C:\allmite-windows\Setup-AllmiteServer.ps1
```

What it does (idempotent — safe to re-run):
1. `winget install OpenJS.NodeJS.LTS` (skipped if `node` works, 18–24 ok).
2. opencode: tries `choco`, then `scoop`, then `npm i -g opencode-ai`
   (first success wins; WSL users should prefer the Linux path instead).
3. Ollama: `winget install Ollama.Ollama`, fallback to the official
   `OllamaSetup.exe` download page message.
4. `npm install -g @musistudio/claude-code-router`.
5. Firewall: inbound TCP 4096 (opencode), 3456 (CCR), 11434 (Ollama).
6. OpenSSH Server capability + service (for `ssh -NL` tunnels from Termux).
7. Writes a starter CCR config if none exists (deepseek placeholder key).

## Serve (after install)

```powershell
$env:OPENCODE_SERVER_PASSWORD="your-secret"
opencode serve --hostname 0.0.0.0 --port 4096   # fixed port is mandatory
ccr start                                        # gateway :3456
ollama serve                                     # :11434 (or the desktop app)
```

Phone connects via Termux SSH tunnel (no firewall needed) or directly
`http://PC_IP:4096` on trusted LAN.

## Files

- `Setup-AllmiteServer.ps1` — the installer (review it first: `-WhatIf` ok).
- `Check-AllmiteServer.ps1` — health report (node/npm/ports/listeners).
- `assets/ccr-config.example.json` — starter CCR config (paste real keys).

## Notes

- **Not tested on a real Windows box from here** (Linux container) — the
  script is careful (checks before acting, stops on first success path)
  but treat the first run as supervised.
- Prefer **WSL2** for opencode power use (`wsl --install`, then the Linux
  addon path inside WSL); native flow above covers serve/gateway duty.
