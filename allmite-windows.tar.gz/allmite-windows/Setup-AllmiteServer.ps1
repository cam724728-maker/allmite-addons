<#
.SYNOPSIS
  Allmite Ai Windows server setup: Node LTS, opencode, CCR, Ollama,
  firewall rules, OpenSSH server, starter CCR config.
.DESCRIPTION
  Idempotent: every step checks first and skips when already satisfied.
  Run in PowerShell AS ADMINISTRATOR. Review with -WhatIf mindset:
  it only installs from official sources (winget/npm) and opens 3 ports.
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param()

$ErrorActionPreference = 'Stop'

# Self-update: this addon is a runtime requirement, so a cloned copy
# refreshes itself first (never fails setup if offline/no git).
if ((Test-Path (Join-Path $PSScriptRoot '.git')) -and (Get-Command git -ErrorAction SilentlyContinue)) {
  & git -C $PSScriptRoot pull --ff-only 2>$null | Out-Null
}

function Test-Cmd($n) { $null -ne (Get-Command $n -ErrorAction SilentlyContinue) }
function Step($msg) { Write-Host "`n=== $msg ===" -ForegroundColor Cyan }
function Ok($msg) { Write-Host "[ok] $msg" -ForegroundColor Green }
function Skip($msg) { Write-Host "[skip] $msg" -ForegroundColor Yellow }

# --- 1. Node.js LTS (18-24) ------------------------------------------------
Step 'Node.js'
$nodeOk = $false
if (Test-Cmd node) {
  $v = (node --version) 2>$null
  if ($v -match 'v(1[89]|2[0-4])\.') { $nodeOk = $true; Ok "node $v present" }
  else { Write-Host "[info] node $v outside 18-24, reinstalling LTS" }
}
if (-not $nodeOk) {
  if (Test-Cmd winget) {
    winget install --silent OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
  }
  if (-not (Test-Cmd node)) { throw 'Node.js install failed — install LTS manually from nodejs.org' }
  Ok "node $(node --version) installed"
}

# --- 2. opencode ------------------------------------------------------------
Step 'opencode'
$ocOk = $false
if (Test-Cmd opencode) { $ocOk = $true; Ok "opencode present" }
foreach ($mgr in @('choco', 'scoop')) {
  if ($ocOk) { break }
  if (Test-Cmd $mgr) {
    if ($mgr -eq 'choco') { choco install opencode -y }
    else { scoop install opencode }
    if (Test-Cmd opencode) { $ocOk = $true }
  }
}
if (-not $ocOk -and (Test-Cmd npm)) {
  npm install -g opencode-ai@latest
  if (Test-Cmd opencode) { $ocOk = $true }
}
if ($ocOk) { Ok 'opencode ready' } else { Write-Host '[warn] opencode not installed — use WSL path instead' -ForegroundColor Yellow }

# --- 3. Ollama ---------------------------------------------------------------
Step 'Ollama'
if (Test-Path "$env:LOCALAPPDATA\Programs\Ollama\ollama.exe") {
  Skip 'Ollama already installed'
} elseif (Test-Cmd winget) {
  winget install --silent Ollama.Ollama --accept-source-agreements --accept-package-agreements
  if (Test-Path "$env:LOCALAPPDATA\Programs\Ollama\ollama.exe") { Ok 'Ollama installed' }
  else { Write-Host '[warn] install OllamaSetup.exe manually from ollama.com/download' -ForegroundColor Yellow }
} else {
  Write-Host '[warn] winget missing — install OllamaSetup.exe manually from ollama.com/download' -ForegroundColor Yellow
}

# --- 4. CCR ------------------------------------------------------------------
Step 'Claude Code Router'
if (-not (Test-Cmd npm)) { throw 'npm missing (Node install above failed?)' }
if (Test-Cmd ccr) { Skip 'ccr already installed' }
else {
  npm install -g @musistudio/claude-code-router
  if (-not (Test-Cmd ccr)) { throw 'CCR install failed' }
}
Ok 'ccr ready'

# --- 4b. cloudflared (tunnel client: expose local servers publicly) ---------
# Verified id: Cloudflare.cloudflared (official docs). No auto-update on
# Windows — re-run winget upgrade manually once in a while.
Step 'cloudflared (tunnels)'
if (Test-Cmd cloudflared) { Skip 'cloudflared already installed' }
elseif (Test-Cmd winget) {
  winget install -e --id Cloudflare.cloudflared --silent --accept-package-agreements --accept-source-agreements
  if (Test-Cmd cloudflared) { Ok 'cloudflared ready' }
  else { Write-Host '[warn] install manually: winget install -e --id Cloudflare.cloudflared' -ForegroundColor Yellow }
} else {
  Write-Host '[warn] winget missing — download cloudflared.exe from developers.cloudflare.com' -ForegroundColor Yellow
}

# --- 5. Firewall (4096 opencode / 3456 CCR / 11434 Ollama) --------------------
Step 'Firewall'
$rule = Get-NetFirewallRule -DisplayName 'Allmite servers' -ErrorAction SilentlyContinue
if ($null -eq $rule) {
  New-NetFirewallRule -DisplayName 'Allmite servers' -Direction Inbound `
    -LocalPort 4096,3456,11434 -Protocol TCP -Action Allow | Out-Null
  Ok 'firewall rule added'
} else { Skip 'firewall rule exists' }

# --- 6. OpenSSH Server (Termux tunnels: ssh -NL 4096:127.0.0.1:4096 user@PC) --
Step 'OpenSSH Server'
$cap = Get-WindowsCapability -Online | Where-Object { $_.Name -like 'OpenSSH.Server*' }
if ($cap.State -ne 'Installed') { Add-WindowsCapability -Online -Name $cap.Name }
Start-Service sshd -ErrorAction SilentlyContinue
Set-Service -Name sshd -StartupType Automatic
Ok 'sshd running (use Windows password or keys from Termux)'

# --- 7. Starter CCR config (only when absent; NEVER overwrites keys) ---------
Step 'CCR config'
$ccrDir = Join-Path $HOME '.claude-code-router'
$config = Join-Path $ccrDir 'config.json'
if (-not (Test-Path $config)) {
  New-Item -ItemType Directory -Force -Path $ccrDir | Out-Null
  Copy-Item (Join-Path $PSScriptRoot 'assets\ccr-config.example.json') $config
  Ok "wrote starter $config — paste your real API keys in it"
} else { Skip 'config.json exists (untouched)' }

Write-Host '`nAll done. Serve with:' -ForegroundColor Green
Write-Host '  $env:OPENCODE_SERVER_PASSWORD="your-secret"; opencode serve --hostname 0.0.0.0 --port 4096'
Write-Host '  ccr start   # gateway :3456'

# --- 8. Verify (read-only health report doubles as the proof) -----------
Step 'Verify'
$check = Join-Path $PSScriptRoot 'Check-AllmiteServer.ps1'
if (Test-Path $check) { & $check } else { Write-Host '[warn] Check-AllmiteServer.ps1 missing' -ForegroundColor Yellow }

Write-Host ''
Write-Host '================ ALLMITE AI — CONNECTION SUMMARY ===============' -ForegroundColor Green
Write-Host 'opencode:  $env:OPENCODE_SERVER_PASSWORD="your-secret"; opencode serve --hostname 0.0.0.0 --port 4096'
Write-Host 'CCR:       ccr start   (gateway http://127.0.0.1:3456/v1)'
Write-Host 'Ollama:    ollama serve  +  ollama pull qwen2.5-coder:7b-instruct'
Write-Host 'Tunnel:    cloudflared tunnel --url http://127.0.0.1:11434  (or 4096/3456)'
Write-Host 'In Allmite Ai: Settings > Add endpoint, base URL = <tunnel-url>/v1'
Write-Host '==============================================================='
