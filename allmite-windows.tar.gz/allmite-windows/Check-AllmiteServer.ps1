<#
.SYNOPSIS
  Health report for the Allmite Ai Windows server role (read-only).
#>
$ErrorActionPreference = 'Continue'

Write-Host '=== Allmite server health ===' -ForegroundColor Cyan
foreach ($c in @('node', 'npm', 'opencode', 'ccr', 'ollama')) {
  $p = (Get-Command $c -ErrorAction SilentlyContinue)?.Source
  Write-Host ("{0,-8} {1}" -f $c, ($p ?? 'MISSING'))
}
foreach ($port in @(4096, 3456, 11434)) {
  $l = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($l) { Write-Host "port $port LISTENING (pid $($l.OwningProcess))" -ForegroundColor Green }
  else { Write-Host "port $port closed" -ForegroundColor Yellow }
}
try {
  $r = Invoke-WebRequest -UseBasicParsing -TimeoutSec 8 http://127.0.0.1:3456/v1/models
  Write-Host "CCR gateway: HTTP $($r.StatusCode)" -ForegroundColor Green
} catch { Write-Host 'CCR gateway: unreachable' -ForegroundColor Yellow }
