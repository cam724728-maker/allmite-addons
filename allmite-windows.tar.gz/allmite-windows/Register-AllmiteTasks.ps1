<#
.SYNOPSIS
  Register Allmite companion scheduled tasks (current user, no admin):
  models sync every 6 hours + feed server at logon.
#>
$ErrorActionPreference = 'Stop'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Sync = Join-Path $Here 'Sync-AllmiteModels.ps1'
$Feed = Join-Path $Here 'feed-server.py'

$py = (Get-Command python -ErrorAction SilentlyContinue)?.Source
if (-not $py) { $py = (Get-Command python3 -ErrorAction SilentlyContinue)?.Source }
if (-not $py) { throw 'Python not found — winget install Python.Python.3 (or python.org) first' }

schtasks /create /tn 'AllmiteModelsSync' `
  /tr "powershell -NoProfile -File `"$Sync`"" `
  /sc HOURLY /mo 6 /f | Out-Null
Write-Host '[ok] sync task: every 6 hours'

schtasks /create /tn 'AllmiteFeed' `
  /tr "`"$py`" `"$Feed`"" `
  /sc ONLOGON /f | Out-Null
Write-Host '[ok] feed task: at logon (http://127.0.0.1:8099/models.json, token-gated)'

Write-Host 'Verify: schtasks /query /tn AllmiteModelsSync'
Write-Host 'Manual: powershell -File Sync-AllmiteModels.ps1 [-Update|-Ensure]'
