#!/data/data/com.termux/files/usr/bin/bash
# Register the periodic models-sync job (Android JobScheduler: survives
# kills better than cron, honors battery/network constraints natively).
# Requires the Termux:API app + `pkg install termux-api`.
set -euo pipefail

ADDON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

termux-job-scheduler --job-id 100 --period-ms 21600000 \
  --network any --battery-not-low true \
  -s "$ADDON_DIR/bin/models-sync.sh"
echo "[jobs] registered (every ~6h, battery-not-low). List: termux-job-scheduler -p"
echo "Manual run anytime: $ADDON_DIR/bin/models-sync.sh now"
