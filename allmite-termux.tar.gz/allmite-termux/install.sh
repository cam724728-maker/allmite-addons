#!/data/data/com.termux/files/usr/bin/bash
# allmite-termux companion for stock Termux (no proot required).
# Installs helper packages, boot hook, scheduled sync job, feed server,
# and prints the pairing token (paste once into the Allmite Ai app).
set -euo pipefail

ADDON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TOKEN_FILE="$HOME/.allmite-token"
FEED_DIR="$HOME/.allmite-feed"
BOOT_DIR="$HOME/.termux/boot"

# Self-update: this addon is a runtime requirement, so a cloned copy
# refreshes itself first (never fails the install if offline).
if [ -d "$ADDON_DIR/.git" ] && command -v git >/dev/null 2>&1; then
  git -C "$ADDON_DIR" pull --ff-only >/dev/null 2>&1 || true
  echo "[allmite-termux] self-updated from git."
fi

echo "[allmite-termux] installing helper packages ..."
pkg install -y termux-api openssh nodejs git python tmux proot-distro 2>/dev/null || {
  echo "open Termux and run: pkg update && pkg install termux-api openssh nodejs git python tmux proot-distro"
}

mkdir -p "$FEED_DIR" "$BOOT_DIR"
chmod +x "$ADDON_DIR"/bin/*.sh "$ADDON_DIR"/jobs/*.sh 2>/dev/null || true

if [ ! -f "$TOKEN_FILE" ]; then
  openssl rand -hex 24 2>/dev/null > "$TOKEN_FILE" || \
    head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n' > "$TOKEN_FILE"
  chmod 600 "$TOKEN_FILE"
  echo "[allmite-termux] NEW pairing token created."
fi

cp "$ADDON_DIR/boot/10-allmite.sh" "$BOOT_DIR/10-allmite.sh"
chmod +x "$BOOT_DIR/10-allmite.sh"

echo "[allmite-termux] registering periodic sync job ..."
"$ADDON_DIR/jobs/setup-jobs.sh" || true

echo
echo "=== pairing token (paste ONCE in Allmite Ai → server settings) ==="
cat "$TOKEN_FILE"
echo
echo "=== feed endpoint (app reads this) ==="
echo "http://127.0.0.1:8099/models.json?token=$(cat "$TOKEN_FILE")"
echo
echo "Start the feed now: nohup python3 $ADDON_DIR/bin/feed-server.py >/dev/null 2>&1 &"
echo "Manual sync now:  $ADDON_DIR/bin/models-sync.sh now"
