#!/data/data/com.termux/files/usr/bin/bash
# allmite-termux companion for stock Termux (no proot required).
# Installs helper packages, boot hook, scheduled sync job, feed server,
# and prints the pairing token (paste once into the Allmite Ai app).
set -euo pipefail

ADDON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TOKEN_FILE="$HOME/.allmite-token"
FEED_DIR="$HOME/.allmite-feed"
BOOT_DIR="$HOME/.termux/boot"

# Self-update: this addon is a runtime requirement, so a cloned copy
# refreshes itself first (never fails the install if offline).
if [ -d "$ADDON_DIR/.git" ] && command -v git >/dev/null 2>&1; then
  git -C "$ADDON_DIR" pull --ff-only >/dev/null 2>&1 || true
  echo "[allmite-termux] self-updated from git."
fi

echo "[allmite-termux] checking helper packages (installed ones are skipped) ..."
# package -> command it provides (checked first, so present tools are
# never re-downloaded).
_missing=""
_check() { command -v "$2" >/dev/null 2>&1 || _missing="$_missing $1"; }
_check termux-api termux-battery-status
_check openssh sshd
_check nodejs node
_check git git
_check python python3
_check tmux tmux
_check proot-distro proot-distro
if [ -z "$_missing" ]; then
  echo "[allmite-termux] all helper packages already present."
else
  echo "[allmite-termux] installing missing:$_missing"
  # shellcheck disable=SC2086
  pkg install -y $_missing 2>/dev/null || {
    echo "open Termux and run: pkg update && pkg install$_missing"
  }
fi

mkdir -p "$FEED_DIR" "$BOOT_DIR"
chmod +x "$ADDON_DIR"/bin/*.sh "$ADDON_DIR"/jobs/*.sh 2>/dev/null || true

if [ ! -f "$TOKEN_FILE" ]; then
  openssl rand -hex 24 2>/dev/null > "$TOKEN_FILE" || \
    head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n' > "$TOKEN_FILE"
  chmod 600 "$TOKEN_FILE"
  echo "[allmite-termux] NEW pairing token created."
fi

cp "$ADDON_DIR/boot/10-allmite.sh" "$BOOT_DIR/10-allmite.sh"
chmod +x "$BOOT_DIR/10-allmite.sh"

echo "[allmite-termux] registering periodic sync job ..."
"$ADDON_DIR/jobs/setup-jobs.sh" || true

echo "[allmite-termux] starting feed server (idempotent) ..."
FEED_URL="http://127.0.0.1:8099/models.json?token=$(cat "$TOKEN_FILE")"
if curl -fsS --max-time 3 "$FEED_URL" >/dev/null 2>&1; then
  echo "[allmite-termux] feed already answering on :8099."
else
  nohup python3 "$ADDON_DIR/bin/feed-server.py" >/dev/null 2>&1 &
  sleep 2
fi

echo "[allmite-termux] first sync ..."
"$ADDON_DIR/bin/models-sync.sh" now || true

echo
echo "================ ALLMITE AI — CONNECTION SUMMARY ==============="
if curl -fsS --max-time 5 "$FEED_URL" >/dev/null 2>&1; then
  echo "Feed:    OK  http://127.0.0.1:8099/models.json?token=YOUR_TOKEN"
else
  echo "Feed:    NOT answering — start it:"
  echo "         nohup python3 $ADDON_DIR/bin/feed-server.py >/dev/null 2>&1 &"
fi
echo "Token:   (paste ONCE in Allmite Ai -> Models sync)"
cat "$TOKEN_FILE"
echo
echo "Status:  http://127.0.0.1:8099/status?token=YOUR_TOKEN"
echo "App actions: sync-now, update, ensure, ensure-packages"
echo "================================================================"
