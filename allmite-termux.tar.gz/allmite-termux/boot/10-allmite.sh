#!/data/data/com.termux/files/usr/bin/bash
# Termux:Boot hook — copy to ~/.termux/boot/ (done by install.sh).
# Re-registers the periodic job after every reboot + feeds once.
~/allmite-termux/jobs/setup-jobs.sh >/dev/null 2>&1 || true
~/allmite-termux/bin/models-sync.sh now >/dev/null 2>&1 || true
