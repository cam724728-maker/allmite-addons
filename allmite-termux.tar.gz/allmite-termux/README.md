# allmite-termux — Allmite Ai companion for stock Termux (no proot)

Runs on the phone itself: environment check, models-sync watcher + local
feed, scheduler wiring, boot hook. Heavy model collection lives in
`allmite-proot` (where the servers run); this addon covers what stock
Termux can do natively (Node/npm tools, env facts, scheduling).

## Install (in Termux, F-Droid build) — one line, fetches the addon itself

```bash
pkg install git -y && git clone https://github.com/cam724728-maker/allmite-addons ~/allmite-addons && ~/allmite-addons/allmite-termux/install.sh
```

> Replace `USER` with the real GitHub org/user once the repos exist (or
> set nothing — any later `git pull` inside `~/allmite-termux` updates it;
> `install.sh` self-updates on every run).

`install.sh` verifies tools, installs the boot hook, registers the
periodic job, prints the pairing token (paste once in the app), and starts
the feed.

## Layout

- `bin/env-check.sh` — prints environment facts as JSON (runtime, node,
  proot distros, termux-api, battery policy).
- `bin/models-sync.sh` — collects what stock Termux can see (npm global
  versions, node version, proot inventory) and refreshes the feed.
- `bin/feed-server.py` — loopback-only HTTP feed (`127.0.0.1:8099`),
  token-gated (`?token=` must match `~/.allmite-token`).
- `POST /command` (same token) runs allow-listed actions async
  (`sync-now`, `update`, `ensure`) — this is how the app triggers
  updates; progress via `GET /jobs/<id>` (see `docs/models-sync-plan.md`
  §10 for the protocol).
- `jobs/setup-jobs.sh` — registers `termux-job-scheduler` (6h, unmetered
  optional, battery-not-low) + manual `models-sync now` usage.
- `boot/10-allmite.sh` — Termux:Boot hook (copy to `~/.termux/boot/`).
- `uninstall.sh` — cancels jobs, removes hook (keeps data).

## Notes

- No `llama-cpp`/`ollama`/`cronie`/`inotify-tools` in Termux repos
  (verified) — polling + job-scheduler instead; local models live in proot.
- Node on Termux tracks latest (26.x now) — heavy Node tools (CCR/npm)
  are safer inside proot with Node 22.
