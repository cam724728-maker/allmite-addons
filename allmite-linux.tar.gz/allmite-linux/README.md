# allmite-linux — Allmite Ai server setup for a Linux PC/server

Desktop/server companion: installs opencode, Ollama, Node LTS, CCR, opens
firewall ports, provides systemd user units, and schedules the
models-sync collector. The phone reaches it via SSH tunnel or LAN.

## Install

One line fetches the addon itself first (replace USER with the real
GitHub org/user once the repos exist):

```bash
git clone https://github.com/cam724728-maker/allmite-addons ~/allmite-addons
cd ~/allmite-addons/allmite-linux
./setup-server.sh        # apt/dnf/pacman auto-detected (sudo as needed)
```

## Serve (after install)

```bash
OPENCODE_SERVER_PASSWORD=your-secret opencode serve --hostname 0.0.0.0 --port 4096
ccr start                                   # gateway :3456
OLLAMA_HOST=0.0.0.0 ollama serve            # :11434
```

Or as user services (survive logout with `loginctl enable-linger $USER`):

```bash
mkdir -p ~/.config/systemd/user
cp systemd/*.service systemd/*.timer ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user enable --now models-sync.timer
# opencode-serve.service: enable only on always-on boxes
```

## Layout

- `setup-server.sh` — distro-aware installer + firewall (ufw/firewalld).
- `systemd/opencode-serve.service` — serve on 0.0.0.0:4096 (edit password!).
- `systemd/models-sync.{service,timer}` — catalog collector every 6h.
- `bin/models-sync.sh` — same collector + `--update`/`--ensure` as the
  proot variant (bigger default `WANT_OLLAMA_MODELS` for servers).
- `bin/feed-server.py` — same protocol on 127.0.0.1:8099 (tunnel it or
  read via LAN with the same token).

## Notes

- **Set the password**: the shipped unit contains `CHANGEME` — the service
  refuses to start until you edit it (fail-closed by design).
- Phone path: Termux `ssh -NL 4096:127.0.0.1:4096 user@HOST` (no firewall
  needed) or direct `http://HOST:4096` on trusted LAN.
