#!/usr/bin/env bash
# Allmite Ai Linux server setup: opencode, Ollama, Node LTS, CCR, firewall.
# Distro-aware (apt/dnf/pacman), idempotent, sudo only where needed.
set -euo pipefail

ADDON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Self-update: this addon is a runtime requirement, so a cloned copy
# refreshes itself first (never fails setup if offline).
if [ -d "$ADDON_DIR/.git" ] && command -v git >/dev/null 2>&1; then
  git -C "$ADDON_DIR" pull --ff-only >/dev/null 2>&1 || true
fi

SUDO=""; [ "$(id -u)" = "0" ] || SUDO="sudo"
have() { command -v "$1" >/dev/null 2>&1; }

# All runtime requirements through one checker (present tools are never
# re-downloaded). Falls back to the inline flow below on any error.
"$(dirname "${BASH_SOURCE[0]}")/bin/ensure-packages.sh" || {
  echo "[setup-server] ensure-packages reported gaps — continuing with inline flow"
}

if have apt-get; then PM=apt-get
elif have dnf; then PM=dnf
elif have pacman; then PM=pacman
else echo "unsupported distro (need apt/dnf/pacman)"; exit 1; fi

install_nodejs() {
  have node && node --version | grep -qE 'v(1[89]|2[0-4])\.' && return 0
  case "$PM" in
    apt-get) curl -fsSL https://deb.nodesource.com/setup_22.x | $SUDO bash -; $SUDO apt-get install -y nodejs ;;
    dnf) $SUDO dnf install -y nodejs ;;
    pacman) $SUDO pacman -Sy --noconfirm nodejs npm ;;
  esac
}

echo "== Node.js =="; install_nodejs; node --version
echo "== opencode =="; have opencode || curl -fsSL https://opencode.ai/install | bash
export PATH="$HOME/.opencode/bin:$PATH"; opencode --version || true
echo "== Ollama =="; have ollama || curl -fsSL https://ollama.com/install.sh | sh
echo "== CCR =="; have ccr || npm install -g @musistudio/claude-code-router
ccr --version 2>/dev/null || true

echo "== firewall =="
if have ufw; then
  $SUDO ufw allow 4096,3456,11434/tcp 2>/dev/null || echo "ufw: open 4096,3456,11434 manually"
elif have firewall-cmd; then
  $SUDO firewall-cmd --permanent --add-port={4096,3456,11434}/tcp 2>/dev/null && $SUDO firewall-cmd --reload || echo "firewalld: open ports manually"
else
  echo "no ufw/firewalld found — open TCP 4096,3456,11434 if you expose LAN (SSH tunnels need nothing)"
fi

echo
echo "Serve: OPENCODE_SERVER_PASSWORD=your-secret opencode serve --hostname 0.0.0.0 --port 4096"
echo "       ccr start   |   OLLAMA_HOST=0.0.0.0 ollama serve"

# --- companion feed (what the app reads) -------------------------------
ADDON_BIN="$ADDON_DIR/bin"
TOKEN_FILE="$HOME/.allmite-token"
if [ ! -f "$TOKEN_FILE" ]; then
  openssl rand -hex 24 2>/dev/null > "$TOKEN_FILE" || \
    head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n' > "$TOKEN_FILE"
  chmod 600 "$TOKEN_FILE"
  echo "[setup-server] NEW pairing token created."
fi
FEED_URL="http://127.0.0.1:8099/models.json?token=$(cat "$TOKEN_FILE")"
if curl -fsS --max-time 3 "$FEED_URL" >/dev/null 2>&1; then
  echo "[setup-server] feed already answering on :8099."
else
  nohup python3 "$ADDON_BIN/feed-server.py" >/dev/null 2>&1 &
  sleep 2
fi
"$ADDON_BIN/models-sync.sh" now || true

echo
echo "================ ALLMITE AI — CONNECTION SUMMARY ==============="
if curl -fsS --max-time 5 "$FEED_URL" >/dev/null 2>&1; then
  echo "Feed:    OK  http://127.0.0.1:8099/models.json?token=YOUR_TOKEN"
else
  echo "Feed:    NOT answering — start it:"
  echo "         nohup python3 $ADDON_BIN/feed-server.py >/dev/null 2>&1 &"
fi
echo "Token:   (paste ONCE in Allmite Ai -> Models sync)"
cat "$TOKEN_FILE"
echo
echo "Status:  http://127.0.0.1:8099/status?token=YOUR_TOKEN"
echo "App actions: sync-now, update, ensure, ensure-packages,"
echo "             update-packages, tunnel"
echo "================================================================"
