# colab/ — Free GPU backends (Colab primary, Kaggle secondary)

> Code comments in English, guides in Arabic (decision #4).

## Contents

| Path | Purpose |
|---|---|
| `codebench_colab.ipynb` | Ready notebook: install → pull model → serve → smoke test → tunnel |
| `scripts/serve_ollama.sh` | Starts Ollama with **any** model (`MODEL` arg, default `qwen2.5-coder:7b-instruct`) |
| `scripts/serve_llamacpp.sh` | Alternative via `llama-server` (CUDA, `--jinja`, `--n-gpu-layers`) |
| `scripts/tunnel.sh` | Multi-provider tunnel chain (decision D1) |

## Colab quickstart (free T4)

1. Runtime → Change runtime type → **T4 GPU**.
2. Open the notebook, pick `MODEL`, Runtime → Run all.
3. Copy the printed `https://…` URL into the app as `<url>/v1` (+ MODEL name).
4. Facts (2026): sessions last **at most ~12 h**, idle ~90 min disconnects,
   weekly GPU quota is dynamic (~15–30 h), disk is ephemeral → keep what
   matters out of the VM. Re-run to reconnect (new URL each time).

## Kaggle deltas (secondary backend)

Same scripts work on Kaggle with these differences:

1. New Notebook → Settings → **Accelerator: GPU** (P100/T4 class) + **Internet: ON**
   (tunnels need egress).
2. Run the cells; `%cd`/`!bash` work the same. If `/opt` is not writable,
   replace `/opt/allmite` with `~/allmite` in the paths.
3. Quotas are weekly + per-session caps — check Kaggle's current limits page;
   treat sessions as disposable like Colab's.
4. If `cloudflared` egress is filtered, force `--provider localhostrun`
   (plain SSH) or `localtunnel`.

## Tunnel chain (decision D1)

`tunnel.sh [port] [--provider auto|cloudflared|localtunnel|localhostrun]`.
All three are free with no account; auto falls through on failure. Quick
tunnels are dev-only (no SLA, ephemeral URLs, no official SSE support) —
the app auto-retries non-streamed when SSE stutters, nothing to configure.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `No GPU detected` | Runtime → Change runtime type → GPU |
| `ollama pull` slow | First download only; big quants take a while |
| Tunnel URL never prints | Try `--provider localtunnel`, then `localhostrun` |
| App streams then stalls | SSE hiccup — app falls back automatically; or pick a smaller model |
| Session died overnight | Expected on free tiers — re-run, paste the new URL |
