#!/usr/bin/env bash
# serve_ollama.sh — start Ollama with any model on Colab.
# Allmite Ai points its "OpenAI-compatible" endpoint at http://127.0.0.1:11434/v1
#
# Usage: bash serve_ollama.sh [MODEL]
#   MODEL can be ANY Ollama library name (ollama.com/library) or ANY Hugging
#   Face GGUF (hf.co/<user>/<repo>:<quant>), e.g:
#     bash serve_ollama.sh qwen2.5-coder:7b-instruct   # default: best agent
#     bash serve_ollama.sh llama3.1:8b-instruct
#     bash serve_ollama.sh hf.co/bartowski/Qwen2.5-Coder-14B-Instruct-GGUF:Q4_K_M
#
# Free T4 limits (~15 GB VRAM): 7-9B quants fit fully on GPU; 14B Q4 fits;
# 27B+ only partially offloads (slow); 70B does not fit. Long contexts also
# eat VRAM — keep the app context limit modest on big models.
# Agent quality needs tool/function calling: qwen-coder/qwen3/llama/mistral
# are good; gemma/phi are weak at tools; deepseek-r1 can't call tools at all.
set -euo pipefail

MODEL="${1:-qwen2.5-coder:7b-instruct}"
PORT="${OLLAMA_HOST:-}"

echo "==> Installing Ollama (amd64)…"
if ! command -v ollama >/dev/null 2>&1; then
  curl -fsSL https://ollama.com/install.sh | sh || {
    # Container-safe fallback
    curl -fsSLo /usr/local/bin/ollama \
      "https://ollama.com/download/ollama-linux-amd64.tgz"
    tar -C /usr/local -xzf /usr/local/bin/ollama
  }
fi

echo "==> Starting Ollama on 127.0.0.1:11434…"
export OLLAMA_HOST="127.0.0.1:11434"
if ! nvidia-smi >/dev/null 2>&1; then
  echo "WARNING: no NVIDIA GPU detected — inference will run on CPU (slow)."
  echo "         In Colab: Runtime > Change runtime type > T4 GPU."
fi
nohup ollama serve > /tmp/ollama.log 2>&1 &

for i in $(seq 1 30); do
  if curl -fsS http://127.0.0.1:11434 >/dev/null 2>&1; then break; fi
  sleep 1
done

echo "==> Pulling $MODEL (first run downloads the weights)…"
ollama pull "$MODEL"

echo "==> Verifying on GPU…"
ollama ps 2>/dev/null || true

echo "==> Done."
echo "Base URL for Allmite Ai:  http://127.0.0.1:11434/v1"
echo "Model:                    $MODEL"
echo
echo "To expose to your phone, run:  bash tunnel.sh 11434"