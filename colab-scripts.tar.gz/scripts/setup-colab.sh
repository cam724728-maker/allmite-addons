#!/usr/bin/env bash
# setup-colab.sh — ONE command: LLM server + model + health check (+ tunnel).
#
# Usage: bash setup-colab.sh [MODEL] [--tunnel auto] [--no-tunnel]
#        [--llama model.gguf] [--port PORT] [--feed-dir DIR] [--model NAME]
#
# Does, in order:
#   1. serve  — Ollama (default) or llama.cpp (--llama) via sibling scripts
#   2. verify — the OpenAI-compatible /v1/models answers on 127.0.0.1:PORT
#   3. tunnel — public URL in the background (unless --no-tunnel),
#              captured to <feed-dir>/tunnel.json (feed-server /tunnel shape)
#   4. summary — one block to paste into Allmite Ai + setup-summary.json
# Any failed server step aborts; a failed tunnel only warns (local API
# still works — re-run tunnel.sh manually to retry).
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODEL="qwen2.5-coder:7b-instruct"
TUNNEL="auto" # auto|cloudflared|localtunnel|localhostrun|no
LLAMA=""
PORT=""
PORT_FLAG=0
FEED_DIR="${FEED_DIR:-/tmp/allmite-feed}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --tunnel) TUNNEL="$2"; shift 2 ;;
    --no-tunnel) TUNNEL="no"; shift 1 ;;
    --llama) LLAMA="$2"; shift 2 ;;
    --port) PORT="$2"; PORT_FLAG=1; shift 2 ;;
    --feed-dir) FEED_DIR="$2"; shift 2 ;;
    --model) MODEL="$2"; shift 2 ;;
    -h|--help) sed -n '2,12p' "${BASH_SOURCE[0]}"; exit 0 ;;
    --*) echo "Unknown option: $1" >&2; exit 2 ;;
    *) MODEL="$1"; shift 1 ;;
  esac
done

mkdir -p "$FEED_DIR"

# --- 1. serve ---------------------------------------------------------
if [ -n "$LLAMA" ]; then
  if [ "$PORT_FLAG" = "0" ]; then PORT="8080"; fi
  echo "==> setup-colab: llama.cpp ($LLAMA) on port $PORT"
  bash "$SCRIPT_DIR/serve_llamacpp.sh" "$LLAMA" --port "$PORT"
  MODEL_LABEL="$(basename "$LLAMA")"
else
  if [ "$PORT_FLAG" = "1" ]; then
    echo "ERROR: --port is only for --llama (Ollama always serves :11434)." >&2
    exit 2
  fi
  PORT="11434"
  echo "==> setup-colab: Ollama ($MODEL)"
  bash "$SCRIPT_DIR/serve_ollama.sh" "$MODEL"
  MODEL_LABEL="$MODEL"
fi

# --- 2. verify ---------------------------------------------------------
echo "==> setup-colab: verifying OpenAI-compatible API …"
MODELS_JSON="$(curl -fsS --max-time 20 "http://127.0.0.1:$PORT/v1/models" || true)"
if [ -z "$MODELS_JSON" ]; then
  echo "ERROR: no answer from http://127.0.0.1:$PORT/v1/models" >&2
  echo "Check the server log: /tmp/ollama.log or /tmp/llama.log" >&2
  exit 1
fi
N_MODELS="$(printf '%s' "$MODELS_JSON" | python3 -c "
import json,sys
try: d=json.load(sys.stdin)
except Exception: print(0); sys.exit(0)
ms=d.get('data',d.get('models',[])); print(len(ms) if isinstance(ms,list) else 0)" 2>/dev/null || echo '?')"
echo "==> setup-colab: API OK ($N_MODELS models listed)."

# --- 3. tunnel ----------------------------------------------------------
TUNNEL_URL=""
TUNNEL_JSON="$FEED_DIR/tunnel.json"
if [ "$TUNNEL" != "no" ]; then
  echo "==> setup-colab: opening public tunnel (provider: $TUNNEL) …"
  rm -f "$TUNNEL_JSON"
  # Background + --persist: survives URL rotation; feed file always fresh.
  nohup bash "$SCRIPT_DIR/tunnel.sh" "$PORT" \
    --provider "$TUNNEL" --feed-file "$TUNNEL_JSON" --persist \
    > "$FEED_DIR/tunnel.log" 2>&1 &
  for _ in $(seq 1 60); do
    if [ -s "$TUNNEL_JSON" ]; then
      TUNNEL_URL="$(python3 -c "
import json,sys
try: print(json.load(open('$TUNNEL_JSON')).get('url',''))
except Exception: print('')" 2>/dev/null || true)"
      [ -n "$TUNNEL_URL" ] && break
    fi
    sleep 2
  done
  if [ -z "$TUNNEL_URL" ]; then
    echo "WARNING: tunnel URL not captured in 120s — local API still works." >&2
    echo "Retry manually: bash $SCRIPT_DIR/tunnel.sh $PORT" >&2
  else
    echo "==> setup-colab: tunnel up: $TUNNEL_URL"
  fi
fi

# --- 4. summary ----------------------------------------------------------
if [ -n "$TUNNEL_URL" ]; then APP_BASE="$TUNNEL_URL/v1"
else APP_BASE="http://127.0.0.1:$PORT/v1"; fi
NOW="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
python3 - "$FEED_DIR/setup-summary.json" <<EOF
import json,sys
try: tun=json.load(open("$TUNNEL_JSON")) if "$TUNNEL_URL" else None
except Exception: tun=None
out={"baseUrl":"$APP_BASE","model":"$MODEL_LABEL","port":$PORT,
 "tunnel":tun,"checkedAt":"$NOW"}
json.dump(out,open(sys.argv[1],"w"),indent=2)
EOF

echo
echo "================ ALLMITE AI — CONNECTION SUMMARY ==============="
echo "Base URL (app endpoint):  $APP_BASE"
echo "Model:                    $MODEL_LABEL"
if [ -n "$TUNNEL_URL" ]; then echo "Tunnel URL:               $TUNNEL_URL"; fi
echo "API check:                OK ($N_MODELS models on :$PORT)"
echo "Details:                  $FEED_DIR/setup-summary.json"
echo "================================================================="
echo "In Allmite Ai: Settings > Add endpoint, paste the Base URL above,"
echo "default model = $MODEL_LABEL, then start a session."
