#!/usr/bin/env bash
# serve_llamacpp.sh — run llama.cpp server with an OpenAI-compatible API.
# Usage: ./serve_llamacpp.sh <model.gguf> [--port 8080] [--n-gpu-layers 99]
set -euo pipefail

MODEL="${1:?usage: serve_llamacpp.sh <model.gguf> [--port PORT] [--n-gpu-layers N]}"
PORT="8080"
NGPU="99"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --port) PORT="$2"; shift 2 ;;
    --n-gpu-layers) NGPU="$2"; shift 2 ;;
    *) shift ;;
  esac
done

# Build llama.cpp if not already built.
if ! command -v llama-server >/dev/null 2>&1 && [ ! -x /opt/llama.cpp/build/bin/llama-server ]; then
  echo "==> Cloning & building llama.cpp…"
  if [ ! -d /opt/llama.cpp ]; then
    git clone --depth 1 https://github.com/ggerganov/llama.cpp /opt/llama.cpp
  fi
  cd /opt/llama.cpp
  cmake -B build -DGGML_CUDA=ON -DGGML_NATIVE=ON
  cmake --build build --config Release -j "$(nproc)"
fi

LLAMA_SERVER="$(command -v llama-server || echo /opt/llama.cpp/build/bin/llama-server)"

echo "==> Starting llama.cpp server on 127.0.0.1:$PORT…"
nohup "$LLAMA_SERVER" \
  -m "$MODEL" \
  --port "$PORT" \
  --host 127.0.0.1 \
  -ngl "$NGPU" \
  --jinja > /tmp/llama.log 2>&1 &

for i in $(seq 1 30); do
  if curl -fsS "http://127.0.0.1:$PORT/v1/models" >/dev/null 2>&1; then break; fi
  sleep 2
done

echo "==> Done."
echo "Base URL for Allmite Ai:  http://127.0.0.1:$PORT/v1"
echo "Model:                    $MODEL"