#!/usr/bin/env bash
# tunnel.sh — expose a local port (Ollama/llama.cpp/opencode) to your phone.
#
# Decision D1: no single free tunnel is reliable forever (quick tunnels are
# dev-only with no SLA and no official SSE support), so this script walks an
# ordered chain of free, no-account providers until one connects:
#   1. cloudflared quick tunnel  (fastest infra, *.trycloudflare.com)
#   2. localtunnel               (free SaaS, *.loca.lt, sometimes overloaded)
#   3. localhost.run             (free SSH reverse tunnel, no account)
#
# Usage: bash tunnel.sh [port] [--provider auto|cloudflared|localtunnel|localhostrun]
#        [--feed-file PATH] [--persist] [--protocol quic|http2]
#   port defaults to 11434 (Ollama). The tunnel runs in the FOREGROUND:
#   keep the cell/process alive and copy the printed https URL into
#   Allmite Ai (endpoint base URL = <url>/v1).
#   --feed-file PATH  write {"url","provider","port","since"} JSON every
#                     time a fresh public URL is captured (the app and the
#                     models-sync companions ingest this — no manual paste).
#   --persist         supervisor loop: restart the provider chain forever
#                     on exit (new URL captured each round). For phones and
#                     day-long Colab sessions; off by default.
#   --protocol        cloudflared transport (default quic). On networks that
#                     filter UDP/7844, use `--protocol http2`.
#
# SSE note: quick tunnels do not officially support server-sent events. If
# live streaming stutters, the app automatically retries non-streamed —
# nothing to configure on this side.
set -euo pipefail

PORT="11434"
PROVIDER="auto"
FEED_FILE=""
PERSIST=0
PROTO=""

while [ $# -gt 0 ]; do
  case "$1" in
    --provider=*) PROVIDER="${1#*=}"; shift ;;
    --provider) PROVIDER="${2:?missing --provider value}"; shift 2 ;;
    --feed-file=*) FEED_FILE="${1#*=}"; shift ;;
    --feed-file) FEED_FILE="${2:?missing --feed-file value}"; shift 2 ;;
    --persist) PERSIST=1; shift ;;
    --protocol=*) PROTO="${1#*=}"; shift ;;
    --protocol) PROTO="${2:?missing --protocol value}"; shift 2 ;;
    [0-9]*) PORT="$1"; shift ;;
    *) echo "Unknown argument: $1 (usage: tunnel.sh [port] [--provider ...] [--feed-file PATH] [--persist] [--protocol ...])" >&2; exit 2 ;;
  esac
done

ARCH="$(uname -m)"
case "$ARCH" in
  x86_64)  CLOUDFLARED_URL="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64" ;;
  aarch64) CLOUDFLARED_URL="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64" ;;
  *) echo "Unsupported architecture: $ARCH" >&2; exit 2 ;;
esac

have() { command -v "$1" >/dev/null 2>&1; }

# Persistent binary dir when possible (/tmp vanishes on reboot — phones
# care). Falls back to /tmp (Colab is ephemeral anyway).
BIN_DIR="/tmp"
for _d in "${HOME:-/tmp}/.local/bin" "${HOME:-/tmp}/bin"; do
  if [ -d "$_d" ] && [ -w "$_d" ]; then BIN_DIR="$_d"; break; fi
done
export PATH="$BIN_DIR:$PATH"

ensure_cloudflared() {
  if have cloudflared; then return 0; fi
  echo "==> Installing cloudflared ($ARCH)…"
  curl -fsSL "$CLOUDFLARED_URL" -o "$BIN_DIR/cloudflared"
  chmod +x "$BIN_DIR/cloudflared"
  have cloudflared
}

# Pass-through filter: prints every tunnel line untouched, and on the
# FIRST public URL writes the feed JSON (provider + port + timestamp).
# Pure function of stdin — unit-tested below via --self-test.
capture_url() {
  local provider_name="$1" line url=""
  while IFS= read -r line; do
    printf '%s\n' "$line"
    if [ -z "$url" ]; then
      # `|| true`: most lines carry no URL and grep exits 1 — without
      # this, set -e + pipefail would kill the parser on the first one.
      # Domains: trycloudflare.com (cloudflared), loca.lt (localtunnel),
      # lhr.life (localhost.run tunnels — NOT localhost.run itself, which
      # is their admin/docs site; verified live 2026-09-27).
      url="$(printf '%s' "$line" | grep -oE 'https://[A-Za-z0-9.-]+\.(trycloudflare\.com|loca\.lt|lhr\.life)[^ [:space:]]*' | head -1 || true)"
      if [ -n "$url" ] && [ -n "$FEED_FILE" ]; then
        printf '{"url": "%s", "provider": "%s", "port": %s, "since": "%s"}\n' \
          "$url" "$provider_name" "$PORT" "$(date -u +%FT%TZ)" > "$FEED_FILE"
        echo "==> tunnel URL captured ($provider_name): $url" >&2
      fi
    fi
  done
  return 0
}

run_cloudflared() {
  ensure_cloudflared || return 1
  echo "==> Provider: cloudflared quick tunnel (free, no account)"
  echo "    Copy the https://*.trycloudflare.com URL below into the app."
  if [ -n "$PROTO" ]; then
    cloudflared tunnel --protocol "$PROTO" --url "http://127.0.0.1:$PORT" 2>&1 | capture_url cloudflared
  else
    cloudflared tunnel --url "http://127.0.0.1:$PORT" 2>&1 | capture_url cloudflared
  fi
}

run_localtunnel() {
  have npx || { echo "localtunnel needs Node (npx missing), skipping." >&2; return 1; }
  echo "==> Provider: localtunnel (free, no account)"
  echo "    Copy the https://*.loca.lt URL below into the app."
  npx --yes localtunnel --port "$PORT" 2>&1 | capture_url localtunnel
}

run_localhostrun() {
  have ssh || { echo "localhost.run needs ssh, skipping." >&2; return 1; }
  echo "==> Provider: localhost.run (free SSH tunnel, no account)"
  echo "    Copy the https://*.lhr.life URL below into the app."
  ssh -o StrictHostKeyChecking=no \
      -o ServerAliveInterval=30 \
      -o ServerAliveCountMax=3 \
      -R "80:127.0.0.1:$PORT" \
      nokey@localhost.run 2>&1 | capture_url localhostrun
}

# One pass over the provider chain (auto mode). Returns the provider's
# status so --persist can loop on it.
run_chain() {
  case "$PROVIDER" in
    cloudflared)   run_cloudflared ;;
    localtunnel)   run_localtunnel ;;
    localhostrun)  run_localhostrun ;;
    auto)
      run_cloudflared && return 0
      echo "!! cloudflared failed, trying localtunnel…" >&2
      run_localtunnel && return 0
      echo "!! localtunnel failed, trying localhost.run…" >&2
      run_localhostrun && return 0
      echo "ERROR: every tunnel provider failed. Check network egress." >&2
      return 1
      ;;
    *) echo "Unknown provider: $PROVIDER (auto|cloudflared|localtunnel|localhostrun)" >&2; exit 2 ;;
  esac
}

if [ "$PERSIST" = "1" ]; then
  while true; do
    run_chain || true
    echo "!! tunnel exited — restarting in 5s (fresh URL will be captured)…" >&2
    sleep 5
  done
else
  run_chain
fi
